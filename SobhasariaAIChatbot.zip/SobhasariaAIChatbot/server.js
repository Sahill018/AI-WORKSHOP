import express from "express";
import OpenAI from "openai";
import fs from "fs";
import path from "path";
import dayjs from "dayjs";

const app = express();
app.use(express.json());

// const openai = new OpenAI({
//   apiKey:"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",
// });

const logFile = path.join("logs.json");

// Simple append log function
function appendLog(entry) {
  let logs = [];
  if (fs.existsSync(logFile)) {
    try {
      logs = JSON.parse(fs.readFileSync(logFile));
    } catch {
      logs = [];
    }
  }
  logs.push(entry);
  fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));
}

app.post("/api/respond", async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: "Prompt required" });

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
    });

    const reply = completion.choices[0].message.content;

    // Log prompt & reply with formatted timestamp
    appendLog({
      time: dayjs().format("YYYY-MM-DD HH:mm:ss"),
      prompt,
      reply,
    });

    res.json({ reply });
  } catch (error) {
    console.error("OpenAI error:", error);
    res.status(500).json({ error: "OpenAI API error" });
  }
});

app.use(express.static("public"));

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
