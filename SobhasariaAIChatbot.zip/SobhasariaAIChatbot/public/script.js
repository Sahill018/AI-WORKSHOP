// // ==========================
// // DOM Elements
// // ==========================
// const startBtn = document.getElementById("start-btn");
// const stopBtn = document.getElementById("stop-btn");
// const sendBtn = document.getElementById("send-btn");
// const chatBox = document.getElementById("chat-box");
// const userInput = document.getElementById("user-input");

// let recognition;
// let isListening = false;

// // ==========================
// // 1️⃣ Custom Q&A with English/Hinglish answers
// // ==========================
// const customQA = [
//   {
//     keys: ["tell me about your self"],
//     answer_en:
//       "Hey there! My self Jia the voice assistant developed by TISA training institute for software and applications"
//   },
//   {
//     keys: ["how are you", "kaise ho", "kya haal hai"],
//     answer_en: "I am doing great! How about you?",
//     answer_hinglish: "Main theek hoon! Aur tum kaise ho?",
//   },
//   {
//     keys: ["hello", "hi", "hey"],
//     answer_en: "Hello! Nice to meet you.",
//     answer_hinglish: "Hello! Aapse milke acha laga.",
//   },
//   {
//     keys: ["how can you help me", "what can you do", "tum kya kar sakte ho"],
//     answer_en: "I can answer your questions and chat with you.",
//     answer_hinglish:
//       "Main aapke questions ka answer de sakta hoon aur aapke saath chat kar sakta hoon.",
//   },
//   {
//     keys: ["bye", "goodbye", "alvida"],
//     answer_en: "Goodbye! Have a nice day.",
//     answer_hinglish: "Bye! Aapka din shubh ho.",
//   },
// ];

// // ==========================
// // 2️⃣ Limit answers to 50 words
// // ==========================
// // function limitWords(text, maxWords = 50) {
// //   const words = text.split(/\s+/);
// //   if (words.length <= maxWords) return text;
// //   return words.slice(0, maxWords).join(" ") + "…";
// // }

// // ==========================
// // 3️⃣ Language detection (English / Hindi / Hinglish)
// // ==========================
// function detectLanguage(text) {
//   const hindiWords = [
//     "namaste",
//     "kaise",
//     "hai",
//     "kya",
//     "ho",
//     "dhanyavaad",
//     "shukriya",
//   ];
//   const words = text.toLowerCase().split(/\s+/);
//   let hindiCount = 0;

//   words.forEach((word) => {
//     if (hindiWords.includes(word)) hindiCount++;
//   });

//   const hindiRegex = /[\u0900-\u097F]/; // Devanagari characters
//   if (hindiRegex.test(text) || hindiCount > 0) return "hindi";
//   return "english";
// }

// // ==========================
// // 4️⃣ Get custom answer based on question language
// // ==========================
// function getCustomAnswer(prompt) {
//   const lowerPrompt = prompt.toLowerCase();
//   const lang = detectLanguage(prompt);

//   for (const item of customQA) {
//     for (const key of item.keys) {
//       if (lowerPrompt.includes(key)) {
//         const answer = lang === "hindi" ? item.answer_hinglish : item.answer_en;
//         return answer
//       }
//     }
//   }
//   return null;
// }

// // ==========================
// // 5️⃣ Speech Recognition Setup
// // ==========================
// if ("webkitSpeechRecognition" in window) {
//   recognition = new webkitSpeechRecognition();
//   recognition.continuous = false;
//   recognition.interimResults = false;
//   recognition.lang = "en-US";

//   recognition.onstart = () => {
//     console.log("🎤 Listening...");
//     startBtn.innerHTML = `<i class="fas fa-microphone-slash"></i>`;
//     startBtn.classList.add("stop");
//     isListening = true;
//   };

//   recognition.onend = () => {
//     console.log("🛑 Stopped listening.");
//     startBtn.innerHTML = `<i class="fas fa-microphone"></i>`;
//     startBtn.classList.remove("stop");
//     isListening = false;
//   };

//   recognition.onresult = (event) => {
//     const transcript = event.results[0][0].transcript;
//     addMessage("user", transcript);
//     sendToServer(transcript);
//   };
// } else {
//   alert("Your browser does not support Speech Recognition. Use Chrome!");
// }

// // ==========================
// // 6️⃣ Speak AI or Custom answer
// // ==========================
// function speakAnswer(text) {
//   if (!window.responsiveVoice) return;

//   responsiveVoice.cancel();
//   stopBtn.style.display = "inline-flex";

//   const lang = detectLanguage(text);
//   const voice = lang === "hindi" ? "Hindi Female" : "UK English Female";

//   responsiveVoice.speak(text, voice, {
//     onend: () => {
//       stopBtn.style.display = "none";
//     },
//   });
// }

// // ==========================
// // 7️⃣ Send message (custom or AI backend)
// // ==========================
// async function sendToServer(prompt) {
//   const customReply = getCustomAnswer(prompt);

//   if (customReply) {
//     addMessage("ai", customReply);
//     speakAnswer(customReply);
//     return;
//   }

//   // Add instruction to AI prompt: "Answer in 50 words max"
//   const promptWithLimit = prompt + " (Please answer in 50 words maximum.)";

//   // Insert loader bubble
//   const loaderDiv = document.createElement("div");
//   loaderDiv.classList.add("msg", "ai-msg");
//   loaderDiv.innerText = "Thinking...";
//   chatBox.appendChild(loaderDiv);
//   chatBox.scrollTop = chatBox.scrollHeight;

//   try {
//     const response = await fetch("/api/respond", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ prompt: promptWithLimit }),
//     });

//     const data = await response.json();

//     if (data.reply) {
//       loaderDiv.innerText = data.reply; // replace loader with AI reply
//       speakAnswer(data.reply);
//     } else {
//       loaderDiv.innerText = "❌ Failed to reach server";
//     }
//   } catch (err) {
//     console.error("Server error:", err);
//     loaderDiv.innerText = "❌ Server error";
//   }
// }

// // ==========================
// // 8️⃣ Append chat message to UI
// // ==========================
// function addMessage(sender, message) {
//   const msgDiv = document.createElement("div");
//   msgDiv.classList.add("msg");
//   msgDiv.classList.add(sender === "user" ? "user-msg" : "ai-msg");
//   msgDiv.innerText = message;
//   chatBox.appendChild(msgDiv);
//   chatBox.scrollTop = chatBox.scrollHeight;
// }

// // ==========================
// // 9️⃣ Start/Stop Listening Button
// // ==========================
// startBtn.addEventListener("click", () => {
//   if (!isListening) recognition.start();
//   else recognition.stop();
// });

// // ==========================
// // 10️⃣ Send button (manual input)
// // ==========================
// sendBtn.addEventListener("click", () => {
//   const text = userInput.value.trim();
//   if (text) {
//     addMessage("user", text);
//     sendToServer(text);
//     userInput.value = "";
//   }
// });

// // ==========================
// // 11️⃣ Stop AI speaking manually
// // ==========================
// stopBtn.addEventListener("click", () => {
//   if (window.responsiveVoice) responsiveVoice.cancel();
//   stopBtn.style.display = "none";
// });

// // ==========================
// // Send message on Enter key
// // ==========================
// userInput.addEventListener("keydown", (e) => {
//   if (e.key === "Enter" && !e.shiftKey) {
//     e.preventDefault(); // prevent newline in input
//     const text = userInput.value.trim();
//     if (text) {
//       addMessage("user", text);
//       sendToServer(text);
//       userInput.value = "";
//     }
//   }
// });






















// ==========================
// DOM Elements
// ==========================
const startBtn = document.getElementById("start-btn");
const stopBtn = document.getElementById("stop-btn");
const sendBtn = document.getElementById("send-btn");
const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");

let recognition;
let isListening = false;

// ==========================
// 1️⃣ Custom Q&A with English/Hinglish answers
// ==========================
const customQA = [
 

  {
    keys: ["hey maya"],
    answer_en: "Hello, how can I assist you?",
  },
  {
    keys: ["tell me about your self"],
    answer_en: "Hey there! My self Maya the voice assistant developed by TISA, training institute for software and applications",
  },
  {
    keys: ["how are you", "kaise ho", "kya haal hai"],
    answer_en: "I am doing great! How about you?",
    answer_hinglish: "Main theek hoon! Aur tum kaise ho?",
  },
  {
    keys: ["hello", "hi", "hey"],
    answer_en: "Hello! Nice to meet you.",
    answer_hinglish: "Hello! Aapse milke acha laga.",
  },
  {
    keys: ["how can you help me", "what can you do", "tum kya kar sakte ho"],
    answer_en: "I can answer your questions and chat with you.",
    answer_hinglish: "Main aapke questions ka answer de sakta hoon aur aapke saath chat kar sakta hoon.",
  },
  {
    keys: ["bye", "goodbye", "alvida"],
    answer_en: "Goodbye! Have a nice day.",
    answer_hinglish: "Bye! Aapka din shubh ho.",
  },
];

// ==========================
// 2️⃣ Language detection (English / Hindi / Hinglish)
// ==========================
function detectLanguage(text) {
  const lower = text.toLowerCase();
  const hinglishWords = ["kaise", "hai", "kya", "ho", "tum", "main", "aap"];
  if (/[\u0900-\u097F]/.test(text)) return "hindi"; // Devanagari
  for (const word of hinglishWords) {
    if (lower.includes(word)) return "hindi"; // treat Hinglish as "hindi"
  }
  return "english";
}

// ==========================
// 3️⃣ Get custom answer based on question language
// ==========================
function getCustomAnswer(prompt) {
  const lowerPrompt = prompt.toLowerCase();
  const lang = detectLanguage(prompt);

  for (const item of customQA) {
    for (const key of item.keys) {
      if (lowerPrompt.includes(key.toLowerCase())) {
        const answer = lang === "hindi" ? (item.answer_hinglish || item.answer_en) : item.answer_en;
        return answer;
      }
    }
  }
  return null;
}

// ==========================
// 4️⃣ Speech Recognition Setup
// ==========================
if ("webkitSpeechRecognition" in window) {
  recognition = new webkitSpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = "en-US";

  recognition.onstart = () => {
    console.log("🎤 Listening...");
    startBtn.innerHTML = `<i class="fas fa-microphone-slash"></i>`;
    startBtn.classList.add("stop");
    isListening = true;
  };

  recognition.onend = () => {
    console.log("🛑 Stopped listening.");
    startBtn.innerHTML = `<i class="fas fa-microphone"></i>`;
    startBtn.classList.remove("stop");
    isListening = false;
  };

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    addMessage("user", transcript);
    sendToServer(transcript);
  };
} else {
  alert("Your browser does not support Speech Recognition. Use Chrome!");
}

// ==========================
// 5️⃣ Speak AI or Custom answer
// ==========================
function speakAnswer(text) {
  if (!window.responsiveVoice) return;

  responsiveVoice.cancel();
  stopBtn.style.display = "inline-flex";

  const lang = detectLanguage(text);
  const voice = lang === "hindi" ? "Hindi Female" : "UK English Female";

  responsiveVoice.speak(text, voice, {
    onend: () => {
      stopBtn.style.display = "none";
    },
  });
}

// ==========================
// 6️⃣ Send message (custom or AI backend)
// ==========================
async function sendToServer(prompt) {
  const customReply = getCustomAnswer(prompt);

  if (customReply) {
    addMessage("ai", customReply);
    speakAnswer(customReply);
    return;
  }

  const promptWithLimit = prompt + " (Please answer in 50 words maximum.)";

  const loaderDiv = document.createElement("div");
  loaderDiv.classList.add("msg", "ai-msg");
  loaderDiv.innerText = "Thinking...";
  chatBox.appendChild(loaderDiv);
  chatBox.scrollTop = chatBox.scrollHeight;

  try {
    const response = await fetch("/api/respond", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: promptWithLimit }),
    });

    const data = await response.json();

    if (data.reply) {
      loaderDiv.innerText = data.reply;
      speakAnswer(data.reply);
    } else {
      loaderDiv.innerText = "❌ Failed to reach server";
    }
  } catch (err) {
    console.error("Server error:", err);
    loaderDiv.innerText = "❌ Server error";
  }
}

// ==========================
// 7️⃣ Append chat message to UI
// ==========================
function addMessage(sender, message) {
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("msg");
  msgDiv.classList.add(sender === "user" ? "user-msg" : "ai-msg");
  msgDiv.innerText = message;
  chatBox.appendChild(msgDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}

// ==========================
// 8️⃣ Start/Stop Listening Button
// ==========================
startBtn.addEventListener("click", () => {
  if (!isListening) recognition.start();
  else recognition.stop();
});

// ==========================
// 9️⃣ Send button (manual input)
// ==========================
sendBtn.addEventListener("click", () => {
  const text = userInput.value.trim();
  if (text) {
    addMessage("user", text);
    sendToServer(text);
    userInput.value = "";
  }
});

// ==========================
// 🔟 Stop AI speaking manually
// ==========================
stopBtn.addEventListener("click", () => {
  if (window.responsiveVoice) responsiveVoice.cancel();
  stopBtn.style.display = "none";
});

// ==========================
// 1️⃣1️⃣ Send message on Enter key
// ==========================
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    const text = userInput.value.trim();
    if (text) {
      addMessage("user", text);
      sendToServer(text);
      userInput.value = "";
    }
  }
});
